<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <!-- Display Lecturer Information -->
    <h2>
        <?php if(isset($lecturer)): ?>
            <?php echo e($lecturer->type == 1 ? 'Dosen' : 'Instruktur'); ?>: <?php echo e($lecturer->name); ?>

        <?php else: ?>
            Pengajar Tidak Ditemukan
        <?php endif; ?>
    </h2>
    <h3>
		<?php if(isset($matkul)): ?>
      		Mata Kuliah: <?php echo e($matkul->name); ?>

      	<?php else: ?>
      		Mata Kuliah Tidak Ditemukan
      	<?php endif; ?>
  	</h3>

    <!-- Table of Groups -->
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Grup</th>
                    <th>Status Evaluasi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr onclick="window.location='<?php echo e(route('admin.evaluation.group.users', ['group_id' => $group->id, 'matkul_id' => $matkul_id, 'lecturer_id' => $lecturer_id])); ?>'"
                        style="cursor:pointer; background-color: <?php echo e($group->allCompleted ? '#e2fade' : '#ffd1d1'); ?>;">
                        <td><?php echo e($group->name); ?></td>
                        <td><?php echo e($group->allCompleted ? 'Semua Evaluasi Selesai' : 'Evaluasi Belum Selesai'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Form to Update Academic Year and Semester -->
    <div class="mt-4">
        <form id="session-form" action="<?php echo e(route('set.session.values')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-row d-flex justify-content-between">
                <!-- Tahun Akademik/Ajaran -->
                <div class="form-group mr-2">
                    <label for="tahunajaran">Tahun Akademik/Ajaran:</label>
                    <input 
                        type="text" 
                        name="tahunajaran" 
                        id="tahunajaran" 
                        class="form-control" 
                        placeholder="2024/2025"
                        value="<?php echo e(session('tahunajaran', '2024/2025')); ?>"
                    >
                </div>

                <!-- Semester -->
                <div class="form-group">
                    <label for="semester">Semester:</label>
                    <input 
                        type="text" 
                        name="semester" 
                        id="semester" 
                        class="form-control" 
                        placeholder="I atau II atau yang lainnya."
                        value="<?php echo e(session('semester', 'I')); ?>"
                    >
                </div>
            </div>
            <div class="text-right mt-3">
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
        </form>
    </div>

    <!-- Button to View Evaluation Summary -->
    <div class="mt-4 text-center">
        <a href="<?php echo e(route('evaluation.summaryTPMO', ['matkulId' => $matkul_id, 'lecturerId' => $lecturer_id])); ?>" class="btn btn-primary">
            Lihat Tabulasi TPMO
        </a>
        <a href="<?php echo e(route('evaluation.summaryTOPKR', ['matkulId' => $matkul_id, 'lecturerId' => $lecturer_id])); ?>" class="btn btn-primary">
            Lihat Tabulasi TOPKR
        </a>
        <div style="display: flex; justify-content: space-between; margin-bottom: 20px;">
            <a class="btn btn-danger" href="<?php echo e(route('admin.home')); ?>">Kembali</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/evaluasi-dosen.akti.ac.id/resources/views/admin/evaluation_groups.blade.php ENDPATH**/ ?>