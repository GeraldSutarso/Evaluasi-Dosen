<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2 class="mb-4">Lecturer Evaluation</h2>

    <!-- Rating Scale Illustration -->
    <div class="p-3 mb-4" style="border: 1px solid #ddd; border-radius: 8px; background-color: #f8f9fa;">
        <h5 class="mb-3 text-center">Scaling Angka</h5>
        
        <div class="rating-scale d-flex justify-content-between align-items-center" style="height: 30px; background: linear-gradient(to right, #ff9999, #ffcc66, #99cc99, #66b3ff); border-radius: 5px; position: relative;">
            <span class="text-white fw-bold" style="position: absolute; left: 0; padding-left: 8px;">1 - Tidak Setuju</span>
            <span class="text-white fw-bold" style="position: absolute; left: 25%;">2 - Kurang Setuju</span>
            <span class="text-white fw-bold" style="position: absolute; left: 50%;">3 - Cukup Setuju</span>
            <span class="text-white fw-bold" style="position: absolute; right: 0; padding-right: 8px;">4 - Sangat Setuju</span>
        </div>
        <p class="mt-3 text-muted text-center">Skor yang lebih tinggi menunjukkan evaluasi yang lebih baik. Harap pilih penilaian anda dengan hati-hati.</p>
    </div>

    <!-- Form to submit the evaluation -->
    <form action="<?php echo e(route('evaluation.submit', $evaluation->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <?php $questionNumber = 1; ?>
        <?php $__currentLoopData = $groupedQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $questions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h3 class="mt-4 mb-3"><?php echo e($type); ?></h3>
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group mb-4">
                    <label class="h5 d-block mb-2"><?php echo e($questionNumber); ?>. <?php echo e($question->text); ?></label>
                    <div class="d-flex gap-3">
                        <!-- Radio buttons for ratings 1 to 4 -->
                        <?php for($i = 1; $i <= 4; $i++): ?>
                            <label class="form-check-label me-3">
                                <input type="radio" name="responses[<?php echo e($question->id); ?>]" value="<?php echo e($i); ?>" required class="form-check-input">
                                <?php echo e($i); ?>

                            </label>
                        <?php endfor; ?>
                    </div>
                </div>
                <?php $questionNumber++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <button onclick='return confirm("Yakinkah anda, akan pilihan anda? Tidakkah anda ingin mempertimbangkan kembali pilihan pada setiap pertanyaan?")' type="submit" class="btn btn-primary mt-4">Submit Evaluation</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/evaluasi-dosen.akti.ac.id/resources/views/evaluation/show.blade.php ENDPATH**/ ?>