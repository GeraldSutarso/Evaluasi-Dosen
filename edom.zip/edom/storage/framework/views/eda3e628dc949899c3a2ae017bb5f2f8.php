

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mt-4">Kalender Pengisian Evaluasi</h1>
    <div class="table-responsive">
        <table class="table table-bordered table-hover text-center mt-4">
            <thead class="table-light">
                <tr>
                    <th class="sticky-header" style="width: 150px;">Group</th>
                    <?php $__currentLoopData = $weeks->sort(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- Sort weeks numerically -->
                        <th class="sticky-header" style="width: 150px;">Week <?php echo e($week); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tableData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupName => $evaluations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="width: 150px;"><?php echo e($groupName); ?></td> <!-- Fixed width for Group column -->
                        <?php $__currentLoopData = $weeks->sort(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(isset($evaluations[$week])): ?>
                                <?php
                                    $isCompleted = $evaluations[$week]['all_completed'];
                                ?>
                                <td class="evaluation-cell" 
                                    style="background-color: <?php echo e($isCompleted ? '#e2fade' : '#ffd1d1'); ?>; width: 150px;">
                                    <a href="<?php echo e(url('/admin/home') . '?week=' . $week . '&group=' . $evaluations[$week]['group_name']); ?>" 
                                    class="d-block w-100 h-100 text-decoration-none text-dark">
                                        <?php echo e($isCompleted ? '✔' : '✘'); ?>

                                    </a>

                                </td>
                            <?php else: ?>
                                <td class="table-light evaluation-cell"></td> <!-- Blank cell for no assigned evaluations -->
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\toyoya\Penilaian Dosen\edom\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>