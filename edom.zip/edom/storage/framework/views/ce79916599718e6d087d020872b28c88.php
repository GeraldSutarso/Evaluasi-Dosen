<?php $__env->startSection('content'); ?>
<main class="login-form">
  <div class="cotainer">
      <div class="row justify-content-center">
          <div class="col-md-8">
              <div class="card">
                  <div class="card-header" style="background-color: #992424"><center><b style="color: aliceblue">Masuk</b></center></div>
                  <div class="card-body">
  
                      <form action="<?php echo e(route('login.post')); ?>" method="POST">
                          <?php echo csrf_field(); ?>
                          <div class="form-group row">
                            <label for="student_id" class="col-md-4 col-form-label text-md-right">NIM:</label>
                            <div class="col-md-6">
                                <input type="text" id="student_id" class="form-control" placeholder="Masukkan NIM Anda" name="student_id" required autofocus>
                            </div>
                            <br>
                            <br>
                            <label class="col-md-4 col-form-label text-md-right">&nbsp;</label>
                            <?php if($errors->any()): ?>
                            <div class="col-md-6 alert alert-danger">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($error); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php endif; ?>
                          </div>                          
                          <div class="col-md-6 offset-md-4">
                              <button type="submit" class="btn btn-primary">
                                  Masuk
                              </button>
                          </div>
                      </form>
                        
                  </div>
              </div>
          </div>
      </div>
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/evaluasi-dosen.akti.ac.id/resources/views/auth/login.blade.php ENDPATH**/ ?>