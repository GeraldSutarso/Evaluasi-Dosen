<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Footer Octave_SRM</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
  </head>
  <body>
    <?php $__env->startSection('footer'); ?>
<footer class="footer">
  <div class="container">
    <div class="row">
      <div class="footer-col">
        <h4>bukan itu adi wkwkw</h4>
        <ul>
          <li><a href="<?php echo e(('about-us')); ?>">about us</a></li>
          <li><a href="<?php echo e(('our-services')); ?>">our services</a></li>
          <li><a href="<?php echo e(('privacy-policy')); ?>">privacy policy</a></li>
          <li><a href="<?php echo e(('octave-allegro')); ?>">octave allegro</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>get person</h4>
        <ul>
          <li><a href="<?php echo e(('faq')); ?>">FAQ</a></li>
          <li><a href="<?php echo e(('shipping')); ?>">shipping</a></li>
          <li><a href="<?php echo e(('returns')); ?>">returns</a></li>
          <li><a href="<?php echo e(('order-status')); ?>">order status</a></li>
          <li><a href="<?php echo e(('aldous-epik')); ?>">Aldous epik</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>online shop Mobile Legends</h4>
        <ul>
          <li><a href="<?php echo e(('diamond')); ?>">Diamond</a></li>
          <li><a href="<?php echo e(('money')); ?>">Money</a></li>
          <li><a href="<?php echo e(('lucky')); ?>">Lucky</a></li>
          <li><a href="<?php echo e(('unlucky')); ?>">Unlucky</a></li>
        </ul>
      </div>
      </div>
    </div>
  </div>
</footer>
    <?php $__env->stopSection(); ?>
  </body>
</html><?php /**PATH D:\Kuliah\toyoya\Penilaian Dosen\edom\resources\views/partial/footer.blade.php ENDPATH**/ ?>