<?php $__env->startSection('content'); ?>
<main class="login-form">
  <div class="cotainer">
      <div class="row justify-content-center">
          <div class="col-md-8">
              <div class="card">
                  <div class="card-header" style="background-color: #992424"><center><b style="color: aliceblue">Verifikasi</b></center></div>
                  <div class="card-body">
  
                      <form action="<?php echo e(route('2fa.verify')); ?>" method="POST">
                          <?php echo csrf_field(); ?>
                          <div class="form-group row">
                            <label for="2fa_code" class="col-md-4 col-form-label text-md-right">Kode Verifikasi:</label>
                            <div class="col-md-6">
                                <input type="text" id="2fa_code" class="form-control" placeholder="Masukkan Kode Verifikasi" name="2fa_code" required autofocus>
                            </div>
                            <br>
                            <br>
                            <label class="col-md-4 col-form-label text-md-right">&nbsp;</label>
                            <?php if($errors->any()): ?>
                            <div class="col-md-6 alert alert-danger">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($error); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php endif; ?>
                          </div>                          
                          <div class="col-md-6 offset-md-4">
                              <button type="submit" class="btn btn-primary">
                                  Masuk
                              </button>
                          </div>
                      </form>
                        
                  </div>
              </div>
          </div>
      </div>
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/evaluasi-dosen.akti.ac.id/public_html/resources/views/auth/2fa.blade.php ENDPATH**/ ?>