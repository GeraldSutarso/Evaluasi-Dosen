<?php $__env->startSection('content'); ?>
<div class="container mt-4">

    <div class="card">
        <div class="card-header">
            <!-- Week Filter Form -->
            <form action="<?php echo e(route('admin.home')); ?>" method="GET" class="d-inline-block me-3">
                <div class="input-group">
                    <select name="week" class="form-select" onchange="this.form.submit()">
                        <option value="">Filter per Minggu</option>
                        <?php for($i = 1; $i <= 21; $i++): ?> <!-- Adjust week range as needed -->
                            <option value="<?php echo e($i); ?>" <?php echo e(request('week') == $i ? 'selected' : ''); ?>>Minggu ke-<?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                    <!-- Preserve Search Term -->
                    <input type="hidden" name="search" value="<?php echo e(request('search')); ?>">
                    <input type="hidden" name="lecturer_type" value="<?php echo e(request('lecturer_type')); ?>">
                </div>
            </form>
        
            <!-- Lecturer Type Filter Form -->
            <form action="<?php echo e(route('admin.home')); ?>" method="GET" class="d-inline-block me-3">
                <div class="input-group">
                    <select name="lecturer_type" class="form-select" onchange="this.form.submit()">
                        <option value="">Filter per Tipe Dosen</option>
                        <option value="1" <?php echo e(request('lecturer_type') == '1' ? 'selected' : ''); ?>>Dosen</option>
                        <option value="2" <?php echo e(request('lecturer_type') == '2' ? 'selected' : ''); ?>>Instruktur</option>
                    </select>
                    <!-- Preserve Other Filter Values -->
                    <input type="hidden" name="week" value="<?php echo e(request('week')); ?>">
                    <input type="hidden" name="search" value="<?php echo e(request('search')); ?>">
                </div>
            </form>
        
            <!-- Search Form -->
            <form action="<?php echo e(route('admin.home')); ?>" method="GET" class="float-end" style="max-width: 300px;">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Cari Matkul atau Dosen" name="search" value="<?php echo e(request('search')); ?>">
                    <!-- Preserve Other Filter Values -->
                    <input type="hidden" name="week" value="<?php echo e(request('week')); ?>">
                    <input type="hidden" name="lecturer_type" value="<?php echo e(request('lecturer_type')); ?>">
                    <button class="btn btn-outline-secondary" type="submit" id="button-search">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                            <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0"/>
                        </svg>
                    </button>
                </div>
            </form>
        </div>
        
        
        
        <div class="card-body">
            <!-- Table -->
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Mata Kuliah</th>
                            <th>Nama Pengajar</th>
                            <th>Tipe Pengajar</th>
                            <th>Minggu Ke</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $evaluations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr onclick="window.location='<?php echo e(route('admin.evaluation.groups', ['matkul_id' => $evaluation->matkul_id, 'lecturer_id' => $evaluation->lecturer_id])); ?>'"
                                style="cursor:pointer;">
                                <td><?php echo e($evaluation->matkul->name ?? 'N/A'); ?></td>
                                <td><?php echo e($evaluation->lecturer->name ?? 'N/A'); ?></td>
                                <td><?php if($evaluation->lecturer->type == 1): ?>Dosen <?php else: ?> Instruktur <?php endif; ?></td>
                                <td><?php echo e($evaluation->week_number); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination Links -->
            <div class="d-flex justify-content-center">
                <?php echo $evaluations->appends(request()->query())->links(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/evaluasi-dosen.akti.ac.id/public_html/resources/views/admin/home.blade.php ENDPATH**/ ?>