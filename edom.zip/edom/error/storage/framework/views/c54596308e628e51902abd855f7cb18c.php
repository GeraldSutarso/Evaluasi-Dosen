<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Nama</th>
                    <th>Status Evaluasi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $evaluation = $user->evaluations->first();
                    ?>
                    <tr style="background-color: <?php echo e($evaluation && $evaluation->completed ? '#e2fade' : '#ffd1d1'); ?>;">
                        <td><?php echo e($user->student_id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($evaluation && $evaluation->completed ? 'Sudah diisi' : 'Belum diisi'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div style="display: flex; justify-content: space-between; margin-bottom: 20px;">
        <a class="btn btn-danger" href="<?php echo e(URL::previous()); ?>">Kembali</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/evaluasi-dosen.akti.ac.id/public_html/resources/views/admin/group_users.blade.php ENDPATH**/ ?>