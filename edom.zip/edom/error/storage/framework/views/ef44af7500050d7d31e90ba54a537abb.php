<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Grup</th>
                    <th>Status Evaluasi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr onclick="window.location='<?php echo e(route('admin.evaluation.group.users', ['group_id' => $group->id, 'matkul_id' => $matkul_id, 'lecturer_id' => $lecturer_id])); ?>'"
                        style="cursor:pointer; background-color: <?php echo e($group->allCompleted ? '#e2fade' : '#ffd1d1'); ?>;">
                        <td><?php echo e($group->name); ?></td>
                        <td><?php echo e($group->allCompleted ? 'Semua Evaluasi Selesai' : 'Evaluasi Belum Selesai'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Button to view evaluation summary -->
    <div class="mt-4 text-center">
        <a href="<?php echo e(route('evaluation.summaryTPMO', ['matkulId' => $matkul_id, 'lecturerId' => $lecturer_id])); ?>" class="btn btn-primary">
            Lihat Tabulasi TPMO
        </a>
        <a href="<?php echo e(route('evaluation.summaryTOPKR', ['matkulId' => $matkul_id, 'lecturerId' => $lecturer_id])); ?>" class="btn btn-primary">
            Lihat Tabulasi TOPKR
        </a>
        <div style="display: flex; justify-content: space-between; margin-bottom: 20px;">
            <a class="btn btn-danger" href="<?php echo e(route('admin.home')); ?>">Kembali</a>
        </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/evaluasi-dosen.akti.ac.id/public_html/resources/views/admin/evaluation_groups.blade.php ENDPATH**/ ?>